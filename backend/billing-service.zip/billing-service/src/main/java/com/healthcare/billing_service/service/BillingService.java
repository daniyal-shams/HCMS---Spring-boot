package com.healthcare.billing_service.service;

import org.hibernate.query.Page;
import org.jvnet.hk2.annotations.Service;
import com.healthcare.billing_service.dto.BillingDto;


@Service
public interface BillingService {

    void createBillingRecord(Long appointmentId, Double amount);

    void updateBillingRecord(Long billingId, Double amount);

    void deleteBillingRecord(Long billingId);

    List<BillingDto> getAllBillingRecords();

    BillingDto getBillingRecordById(Long billingId);

    //pagination and sorting
    Page<BillingDto> getAllBillingRecords(int page, int size, String sortBy, String sortDir);   



}
