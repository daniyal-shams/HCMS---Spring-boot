package com.healthcare.report_service.client;

import com.healthcare.report_service.dto.PatientDto;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

import org.hibernate.query.Page;
import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(name = "patient-service")
public interface PatientServiceClient {

    @GetMapping("/api/patients")
    Page<PatientDto> getAllPatients(@RequestParam("page") int page, @RequestParam("size") int size);
}