package com.healthcare.report_service.client;

import com.healthcare.report_service.dto.AppointmentDto;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestParam;

import com.healthcare.appointment_service.dto.AppointmentDto;

@FeignClient(name = "appointment-service")
public interface AppointmentServiceClient {

    @GetMapping("/api/appointments")
    Page<AppointmentDto> getAllAppointments(@RequestParam("page") int page, @RequestParam("size") int size);
}
