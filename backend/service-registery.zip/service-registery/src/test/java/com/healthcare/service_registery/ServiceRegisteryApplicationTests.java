package com.healthcare.service_registery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegisteryApplicationTests {

	@Test
	void contextLoads() {
	}

}
