package com.healthcare.doctor_service.mapper;

import com.healthcare.doctor_service.dto.DoctorDto;
import com.healthcare.doctor_service.model.Doctor;

public class DoctorMapper {

    public static DoctorDto toDto(Doctor doctor) {
        return new DoctorDto(
                doctor.getId(),
                doctor.getName(),
                doctor.getSpecialization(),
                doctor.getContactNumber(),
                doctor.getEmail()
        );
    }

    public static Doctor toEntity(DoctorDto doctorDto) {
        Doctor doctor = new Doctor();
        doctor.setId(doctorDto.getId());
        doctor.setName(doctorDto.getName());
        doctor.setSpecialization(doctorDto.getSpecialization());
        doctor.setContactNumber(doctorDto.getContactNumber());
        doctor.setEmail(doctorDto.getEmail());
        return doctor;
    }
}