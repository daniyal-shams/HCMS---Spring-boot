package com.healthcare.file_service.service;

import com.healthcare.file_service.dto.FileDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class FileServiceImpl implements FileService {

    private static final Logger logger = LoggerFactory.getLogger(FileServiceImpl.class);

    private final Path rootDirectory = Paths.get("uploads");
    private final Map<Long, FileDto> fileStorage = new ConcurrentHashMap<>();
    private Long fileIdCounter = 1L;

    public FileServiceImpl() {
        try {
            Files.createDirectories(rootDirectory);
            logger.info("Storage directory initialized at {}", rootDirectory.toAbsolutePath());
        } catch (IOException e) {
            logger.error("Could not initialize storage directory", e);
            throw new RuntimeException("Could not initialize storage directory", e);
        }
    }

    @Override
    public String uploadFile(String fileName, String fileType, String filePath, Long fileSize) {
        logger.debug("Uploading file: {}, Type: {}, Path: {}, Size: {}", fileName, fileType, filePath, fileSize);
        try {
            Path sourcePath = Paths.get(filePath);
            Path destinationPath = rootDirectory.resolve(fileName).normalize();
            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);

            FileDto fileDto = new FileDto(fileIdCounter++, fileName, fileType, destinationPath.toString(), fileSize);
            fileStorage.put(fileDto.getId(), fileDto);

            logger.info("File uploaded successfully with ID: {}", fileDto.getId());
            return "File uploaded successfully with ID: " + fileDto.getId();
        } catch (IOException e) {
            logger.error("Failed to upload file", e);
            throw new RuntimeException("Failed to upload file", e);
        }
    }

    @Override
    public String downloadFile(Long fileId) {
        logger.debug("Downloading file with ID: {}", fileId);
        FileDto fileDto = fileStorage.get(fileId);
        if (fileDto == null) {
            logger.warn("File not found with ID: {}", fileId);
            return "File not found with ID: " + fileId;
        }
        logger.info("File available for download at path: {}", fileDto.getFilePath());
        return "File available for download at path: " + fileDto.getFilePath();
    }

    @Override
    public String deleteFile(Long fileId) {
        logger.debug("Deleting file with ID: {}", fileId);
        FileDto fileDto = fileStorage.remove(fileId);
        if (fileDto == null) {
            logger.warn("File not found with ID: {}", fileId);
            return "File not found with ID: " + fileId;
        }
        try {
            Files.deleteIfExists(Paths.get(fileDto.getFilePath()));
            logger.info("File deleted successfully with ID: {}", fileId);
            return "File deleted successfully with ID: " + fileId;
        } catch (IOException e) {
            logger.error("Failed to delete file", e);
            throw new RuntimeException("Failed to delete file", e);
        }
    }

    @Override
    public String getFileDetails(Long fileId) {
        logger.debug("Fetching details for file with ID: {}", fileId);
        FileDto fileDto = fileStorage.get(fileId);
        if (fileDto == null) {
            logger.warn("File not found with ID: {}", fileId);
            return "File not found with ID: " + fileId;
        }
        logger.info("File details retrieved: {}", fileDto);
        return fileDto.toString();
    }

    @Override
    public String listAllFiles() {
        logger.debug("Listing all files");
        if (fileStorage.isEmpty()) {
            logger.info("No files available");
            return "No files available.";
        }
        logger.info("Files listed successfully");
        return fileStorage.values().stream()
                .map(FileDto::toString)
                .collect(Collectors.joining("\n"));
    }

    @Override
    public String updateFile(Long fileId, String fileName, String fileType, String filePath, Long fileSize) {
        logger.debug("Updating file with ID: {}", fileId);
        FileDto fileDto = fileStorage.get(fileId);
        if (fileDto == null) {
            logger.warn("File not found with ID: {}", fileId);
            return "File not found with ID: " + fileId;
        }
        try {
            Path sourcePath = Paths.get(filePath);
            Path destinationPath = rootDirectory.resolve(fileName).normalize();
            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);

            fileDto.setFileName(fileName);
            fileDto.setFileType(fileType);
            fileDto.setFilePath(destinationPath.toString());
            fileDto.setFileSize(fileSize);

            logger.info("File updated successfully with ID: {}", fileId);
            return "File updated successfully with ID: " + fileId;
        } catch (IOException e) {
            logger.error("Failed to update file", e);