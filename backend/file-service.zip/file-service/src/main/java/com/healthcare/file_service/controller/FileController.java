package com.healthcare.file_service.controller;

import com.healthcare.file_service.model.File;
import com.healthcare.file_service.service.FileService;

import org.hibernate.engine.jdbc.env.internal.LobCreationLogging_.logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/files")
public class FileController {
    private static final Logger logger = LoggerFactory.getLogger(FileController.class);
    private final FileService fileService;

    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    @PostMapping("/upload")
    public ResponseEntity<File> uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
        logger.info("Uploading file: {}", file.getOriginalFilename());
        return ResponseEntity.ok(fileService.uploadFile(file));
    }

    @GetMapping
    public ResponseEntity<List<File>> getAllFiles() {
        logger.info("Fetching all files");
        return ResponseEntity.ok(fileService.getAllFiles());
    }

    @GetMapping("/{id}")
    public ResponseEntity<File> getFileById(@PathVariable Long id) {
        logger.info("Fetching file with ID: {}", id);
        return ResponseEntity.ok(fileService.getFileById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFile(@PathVariable Long id) {
        logger.info("Deleting file with ID: {}", id);
        fileService.deleteFile(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> downloadFile(@PathVariable Long id) {
        logger.info("Downloading file with ID: {}", id);
        return ResponseEntity.ok(fileService.downloadFile(id));
    }
    @GetMapping("/download")
    public ResponseEntity<byte[]> downloadFile(@RequestParam String fileName) {
        logger.info("Downloading file with name: {}", fileName);
        return ResponseEntity.ok(fileService.downloadFile(fileName));
    }
    @GetMapping("/download/all")
    public ResponseEntity<List<byte[]>> downloadAllFiles() {
        logger.info("Downloading all files");
        return ResponseEntity.ok(fileService.downloadAllFiles());
    }
    @GetMapping("/download/all/{userId}")
    public ResponseEntity<List<byte[]>> downloadAllFilesByUserId(@PathVariable Long userId) {
        logger.info("Downloading all files for user ID: {}", userId);
        return ResponseEntity.ok(fileService.downloadAllFilesByUserId(userId));
    }
    @GetMapping("/download/all/{userId}/{fileName}")
    public ResponseEntity<byte[]> downloadFileByUserId(@PathVariable Long userId, @PathVariable String fileName) {
        logger.info("Downloading file with name: {} for user ID: {}", fileName, userId);
        return ResponseEntity.ok(fileService.downloadFileByUserId(userId, fileName));
    }
    @GetMapping("/download/all/{userId}/{fileName}/{fileType}")
    public ResponseEntity<byte[]> downloadFileByUserIdAndFileType(@PathVariable Long userId, @PathVariable String fileName, @PathVariable String fileType) {
        logger.info("Downloading file with name: {} and type: {} for user ID: {}", fileName, fileType, userId);
        return ResponseEntity.ok(fileService.downloadFileByUserIdAndFileType(userId, fileName, fileType));
    }
}