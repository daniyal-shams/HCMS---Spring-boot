package com.healthcare.patient_service.service;

import com.healthcare.patient_service.dto.PatientDto;
import com.healthcare.patient_service.exception.PatientNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PatientServiceImpl implements PatientService {

    private final List<PatientDto> patientDatabase = new ArrayList<>(); 

    @Override
    public List<PatientDto> getAllPatients() {
        return patientDatabase;
    }

    @Override
    public PatientDto getPatientById(Long id) {
        return patientDatabase.stream()
                .filter(patient -> patient.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new PatientNotFoundException("Patient with ID " + id + " not found", null, id));
    }

    @Override
    public PatientDto createPatient(PatientDto patientDto) {
        patientDto.setId((long) (patientDatabase.size() + 1)); 
        patientDatabase.add(patientDto);
        return patientDto;
    }

    @Override
    public PatientDto updatePatient(Long id, PatientDto patientDto) {
        PatientDto existingPatient = getPatientById(id);
        existingPatient.setFirstName(patientDto.getFirstName());
        existingPatient.setLastName(patientDto.getLastName());
        existingPatient.setEmail(patientDto.getEmail());
        existingPatient.setPhoneNumber(patientDto.getPhoneNumber());
        existingPatient.setAddress(patientDto.getAddress());
        existingPatient.setDateOfBirth(patientDto.getDateOfBirth());
        return existingPatient;
    }

    @Override
    public void deletePatient(Long id) {
        PatientDto patient = getPatientById(id);
        patientDatabase.remove(patient);
    }

    @Override
    public List<PatientDto> getPatients(int page, int size, String sortBy, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        PageRequest pageRequest = PageRequest.of(page, size, sort);

        // Simulating pagination
        int start = (int) pageRequest.getOffset();
        int end = Math.min((start + pageRequest.getPageSize()), patientDatabase.size());
        return patientDatabase.subList(start, end);
    }

    @Override
    public List<PatientDto> searchPatients(String keyword, int page, int size, String sortBy, String sortDirection) {
        List<PatientDto> filteredPatients = new ArrayList<>();
        for (PatientDto patient : patientDatabase) {
            if (patient.getFirstName().contains(keyword) || patient.getLastName().contains(keyword) ||
                patient.getEmail().contains(keyword)) {
                filteredPatients.add(patient);
            }
        }

        Sort sort = sortDirection.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        PageRequest pageRequest = PageRequest.of(page, size, sort);

        // Simulating pagination
        int start = (int) pageRequest.getOffset();
        int end = Math.min((start + pageRequest.getPageSize()), filteredPatients.size());
        return filteredPatients.subList(start, end);
    }
}