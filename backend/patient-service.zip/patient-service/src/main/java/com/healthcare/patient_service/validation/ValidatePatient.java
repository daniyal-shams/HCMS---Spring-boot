package com.healthcare.patient_service.validation;

import com.healthcare.patient_service.model.Patient;

public class ValidatePatient {

    public static boolean validatePatient(Patient patient) {
        if (patient.getName() == null || patient.getName().isEmpty()) {
            return false;
        }
        if (patient.getEmail() == null || !patient.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            return false;
        }
        if (patient.getPhone() == null || !patient.getPhone().matches("^[0-9]{10}$")) {
            return false;
        }
        if (patient.getAddress() == null || patient.getAddress().isEmpty()) {
            return false;
        }
        if (patient.getDateOfBirth() == null || !patient.getDateOfBirth().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            return false;
        }
        return true;
    }

}
