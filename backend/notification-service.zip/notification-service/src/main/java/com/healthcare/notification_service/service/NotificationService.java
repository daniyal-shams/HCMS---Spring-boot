package com.healthcare.notification_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;

import com.healthcare.notification_service.client.AppointmentServiceClient;
import com.healthcare.notification_service.client.PatientServiceClient;
import com.healthcare.notification_service.dto.*;

import org.thymeleaf.context.Context;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;



@Service
public class NotificationService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private PatientServiceClient patientServiceClient;

    @Autowired
    private AppointmentServiceClient appointmentServiceClient;

    public void sendEmailWithTemplate(NotificationDto notification) {
        try {
            PatientDto patient = patientServiceClient.getPatientById(notification.getPatientId());
            AppointmentDto appointment = appointmentServiceClient.getAppointmentById(notification.getAppointmentId());

            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(notification.getRecipient());
            helper.setSubject(notification.getSubject());

            Context context = new Context();
            context.setVariable("name", patient.getFirstName() + " " + patient.getLastName());
            context.setVariable("doctorName", appointment.getDoctorName());
            context.setVariable("appointmentDate", appointment.getAppointmentDate());
            context.setVariable("appointmentTime", appointment.getAppointmentTime());
            String htmlContent = templateEngine.process("email-template", context);
            helper.setText(htmlContent, true); 
            mailSender.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send email", e);
        }
    }

}