package com.healthcare.notification_service.dto;

public class NotificationDto {
    private String recipient;
    private String subject;
    private String message;
    private Long patientId;
    private Long appointmentId;

    public NotificationDto() {
    }
    public NotificationDto(String recipient, String subject, String message , Long patientId, Long appointmentId) {
        this.recipient = recipient;
        this.subject = subject;
        this.message = message;
        this.patientId = patientId;
        this.appointmentId = appointmentId;
    }
    public String getRecipient() {
        return recipient;
    }
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public Long getPatientId() {
        return patientId;
    }
    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }
    public Long getAppointmentId() {
        return appointmentId;
    }
    public void setAppointmentId(Long appointmentId) {
        this.appointmentId = appointmentId;
    }
    
    @Override
    public String toString() {
        return "NotificationDto{" +
                "recipient='" + recipient + '\'' +
                ", subject='" + subject + '\'' +
                ", message='" + message + '\'' +
                ", patientId=" + patientId +
                ", appointmentId=" + appointmentId +
                '}';
    }

}