package com.healthcare.nurse_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NurseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
